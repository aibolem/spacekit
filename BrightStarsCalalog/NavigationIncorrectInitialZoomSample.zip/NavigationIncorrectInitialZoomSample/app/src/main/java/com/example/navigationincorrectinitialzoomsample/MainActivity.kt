package com.example.navigationincorrectinitialzoomsample

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import com.mapbox.api.directions.v5.DirectionsCriteria
import com.mapbox.api.directions.v5.models.DirectionsRoute
import com.mapbox.geojson.Point
import com.mapbox.mapboxsdk.Mapbox
import com.mapbox.mapboxsdk.maps.MapboxMap
import com.mapbox.services.android.navigation.ui.v5.NavigationViewOptions
import com.mapbox.services.android.navigation.ui.v5.OnNavigationReadyCallback
import com.mapbox.services.android.navigation.ui.v5.camera.NavigationCamera
import com.mapbox.services.android.navigation.ui.v5.listeners.NavigationListener
import com.mapbox.services.android.navigation.ui.v5.listeners.RouteListener
import com.mapbox.services.android.navigation.v5.navigation.MapboxNavigation
import com.mapbox.services.android.navigation.v5.navigation.MapboxNavigationOptions
import com.mapbox.services.android.navigation.v5.navigation.NavigationRoute
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.toast

class MainActivity : AppCompatActivity(), OnNavigationReadyCallback, NavigationListener {

	private val startPointArg = Point.fromLngLat(4.3670787, 50.8431654)
	private val endPointArg = Point.fromLngLat(4.351349, 50.8398872)

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)

		navigationView.onCreate(savedInstanceState)
		navigationView.initialize(this)
	}


	override fun onStart() {
		super.onStart()
		navigationView.onStart()
	}

	override fun onResume() {
		super.onResume()
		navigationView.onResume()
	}

	override fun onLowMemory() {
		super.onLowMemory()
		navigationView.onLowMemory()
	}

	override fun onSaveInstanceState(outState: Bundle) {
		navigationView.onSaveInstanceState(outState)
		super.onSaveInstanceState(outState)
	}

	override fun onRestoreInstanceState(savedInstanceState: Bundle) {
		super.onRestoreInstanceState(savedInstanceState)
		navigationView.onRestoreInstanceState(savedInstanceState)
	}

	override fun onPause() {
		super.onPause()
		navigationView.onPause()
	}

	override fun onStop() {
		super.onStop()
		navigationView.onStop()
	}

	override fun onDestroy() {
		super.onDestroy()
		navigationView.onDestroy()
	}

	override fun onNavigationReady(isRouting: Boolean) {
		val routeViewModel = ViewModelProviders.of(this).get(NavigationRouteViewModel::class.java)
		routeViewModel.routeLiveData.observe(this, Observer {
			startNavigation(it!!)
		})
		routeViewModel.fetchRoute(startPointArg, endPointArg!!)

	}

	override fun onNavigationRunning() {
	}

	override fun onNavigationFinished() {
	}


	private fun startNavigation(directionsRoute: DirectionsRoute) {
		val navigationOptions = MapboxNavigationOptions.builder()
				.snapToRoute(false)
				.isFromNavigationUi(true)

		val options = NavigationViewOptions.builder()
				.navigationListener(this)
				.directionsRoute(directionsRoute)
				.directionsProfile(DirectionsCriteria.PROFILE_CYCLING)
				.waynameChipEnabled(false)
				.navigationOptions(navigationOptions.build())
		navigationView.startNavigation(options.build())
	}

	override fun onCancelNavigation() {
	}
}
