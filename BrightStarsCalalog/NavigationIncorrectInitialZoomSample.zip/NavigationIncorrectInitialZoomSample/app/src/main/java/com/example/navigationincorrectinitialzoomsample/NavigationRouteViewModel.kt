package com.example.navigationincorrectinitialzoomsample

import android.app.Application
import android.arch.lifecycle.AndroidViewModel
import android.arch.lifecycle.MutableLiveData
import com.mapbox.api.directions.v5.DirectionsCriteria
import com.mapbox.api.directions.v5.models.DirectionsResponse
import com.mapbox.api.directions.v5.models.DirectionsRoute
import com.mapbox.geojson.Point
import com.mapbox.mapboxsdk.Mapbox
import com.mapbox.services.android.navigation.v5.navigation.NavigationRoute
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException

class NavigationRouteViewModel(application: Application) : AndroidViewModel(application) {

	val routeLiveData = MutableLiveData<DirectionsRoute>()

	private var currentCall: NavigationRoute? = null

	fun fetchRoute(from: Point, end: Point) {
		currentCall = NavigationRoute.builder(getApplication())
				.accessToken(Mapbox.getAccessToken()!!)
				.origin(from)
				.destination(end)
				.profile(DirectionsCriteria.PROFILE_CYCLING)
				.voiceUnits(DirectionsCriteria.METRIC)
				.build()

		currentCall?.cancelCall()
		currentCall?.getRoute(object : Callback<DirectionsResponse> {
			override fun onFailure(call: Call<DirectionsResponse>?, t: Throwable) {
			}

			override fun onResponse(call: Call<DirectionsResponse>?, response: Response<DirectionsResponse>) {
				if (response.isSuccessful) {
					val routes = response.body()?.routes()
					if (routes?.isNotEmpty() == true) {
						routeLiveData.postValue(routes[0])
					} else {
					}

				}
			}
		})
	}

	override fun onCleared() {
		super.onCleared()
		currentCall?.cancelCall()
	}
}